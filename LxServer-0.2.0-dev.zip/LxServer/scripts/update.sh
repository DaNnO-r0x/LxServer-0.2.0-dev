#!/bin/sh
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run as root'; exit 1; }
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
case "$(uname -m)" in armv7l) arch=arm;; aarch64) arch=arm64;; x86_64) arch=amd64;; *) echo 'Unsupported architecture'; exit 1;; esac
source_dir="$root/dist/linux-$arch"
[ -x "$source_dir/lxserver" ] && [ -x "$source_dir/lhsctl" ] || { echo 'Run make linux first'; exit 1; }
"$source_dir/lxserver" -config /etc/lxserver/config.yaml -check
stamp=$(date +%Y%m%d%H%M%S)
rollback="/usr/local/lib/lxserver/rollback-$stamp"
[ ! -e "$rollback" ] || { echo 'Recovery directory already exists'; exit 1; }
install -d -m 0700 "$rollback"
install -m 0755 /usr/local/bin/lxserver "$rollback/lxserver"
install -m 0755 /usr/local/bin/lhsctl "$rollback/lhsctl"
install -m 0644 /etc/systemd/system/lxserver.service "$rollback/lxserver.service"
# Snapshot succeeds before any running installation is replaced.
runuser -u lxserver -- /usr/local/bin/lhsctl backup "/var/lib/lxserver/pre-update-$stamp.db"
recover() {
 result=$?
 if [ "$result" -ne 0 ]; then
  install -m 0755 "$rollback/lxserver" /usr/local/bin/lxserver
  install -m 0755 "$rollback/lhsctl" /usr/local/bin/lhsctl
  install -m 0644 "$rollback/lxserver.service" /etc/systemd/system/lxserver.service
  systemctl daemon-reload
  systemctl start lxserver || true
  echo "Update failed; old binaries restored. Database snapshot: /var/lib/lxserver/pre-update-$stamp.db" >&2
 fi
}
trap recover 0
systemctl stop lxserver
"$root/scripts/install.sh"
systemctl start lxserver
trap - 0
echo "Updated. Old binaries preserved in $rollback; configuration preserved."
