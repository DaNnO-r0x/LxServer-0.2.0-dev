#!/bin/sh
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run as root'; exit 1; }
[ "$(uname -s)" = Linux ] || { echo 'Linux required'; exit 1; }
command -v systemctl >/dev/null
command -v ss >/dev/null || { echo 'Install iproute2 first'; exit 1; }
case "$(uname -m)" in armv7l) arch=arm;; aarch64) arch=arm64;; x86_64) arch=amd64;; *) echo 'Unsupported architecture'; exit 1;; esac
root=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
source_dir="$root/dist/linux-$arch"
[ -x "$source_dir/lxserver" ] && [ -x "$source_dir/lhsctl" ] || { echo 'Release binary missing for this architecture'; exit 1; }
"$source_dir/lxserver" -config "$root/configs/config.example.yaml" -check
if ss -ltn 'sport = :6699' | sed 1d | sed -n 1p | read -r occupied; then
 echo 'Example TCP port 6699 is occupied; adjust configuration before starting the WinMX listener.'
fi
if ! getent group lxserver >/dev/null; then groupadd --system lxserver; fi
if ! id lxserver >/dev/null 2>&1; then useradd --system --gid lxserver --home-dir /var/lib/lxserver --shell /usr/sbin/nologin lxserver; fi
[ "$(id -u lxserver)" -ne 0 ] || { echo "Refusing a service account with UID 0"; exit 1; }
install -d -m 0750 -o root -g lxserver /etc/lxserver
install -d -m 0700 -o lxserver -g lxserver /var/lib/lxserver
if [ ! -e /etc/lxserver/config.yaml ]; then install -m 0640 -o root -g lxserver "$root/configs/config.example.yaml" /etc/lxserver/config.yaml; else echo 'Existing configuration preserved'; fi
install -m 0755 "$source_dir/lxserver" /usr/local/bin/lxserver
install -m 0755 "$source_dir/lhsctl" /usr/local/bin/lhsctl
if [ ! -e /etc/systemd/system/lxserver.service ]; then
 install -m 0644 "$root/systemd/lxserver.service" /etc/systemd/system/lxserver.service
else
 echo "Existing systemd unit preserved; review packaged systemd/lxserver.service for changes."
fi
systemctl daemon-reload
echo 'Installed. Review /etc/lxserver/config.yaml, then systemctl enable --now lxserver'
echo 'Admin: sudo -u lxserver lhsctl status. WPN is disabled in the example configuration.'
