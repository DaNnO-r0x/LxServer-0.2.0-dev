#!/bin/sh
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run as root'; exit 1; }
systemctl disable --now lxserver.service
rm -f /etc/systemd/system/lxserver.service /usr/local/bin/lxserver /usr/local/bin/lhsctl
systemctl daemon-reload
echo 'Removed software; configuration, database, backups and service user preserved.'
