#!/bin/sh
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run as root'; exit 1; }
[ "$#" = 1 ] || { echo 'Usage: restore.sh /absolute/path/snapshot.db'; exit 1; }
case "$1" in /*) ;; *) echo 'Absolute backup path required'; exit 1;; esac
/usr/local/bin/lxserver -verify-backup "$1"
# These paths match the supplied service/config. Preserve all existing state first.
database=/var/lib/lxserver/lxserver.db
stamp=$(date +%Y%m%d%H%M%S)
saved="/var/lib/lxserver/pre-restore-$stamp"
[ ! -e "$saved" ] || { echo 'Recovery directory exists'; exit 1; }
install -d -m 0700 -o lxserver -g lxserver "$saved"
# Copy and validate before stopping; do not consume the caller's backup.
install -m 0600 -o lxserver -g lxserver "$1" "$saved/restore.db"
/usr/local/bin/lxserver -verify-backup "$saved/restore.db"
systemctl stop lxserver
for suffix in '' '-wal' '-shm'; do
 if [ -e "$database$suffix" ]; then mv "$database$suffix" "$saved/lxserver.db$suffix"; fi
done
mv "$saved/restore.db" "$database"
if ! systemctl start lxserver; then
 echo "Startup failed; original state is preserved in $saved" >&2
 exit 1
fi
echo "Restored. Previous state preserved in $saved"
