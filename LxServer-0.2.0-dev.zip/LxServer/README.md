# LxServer Linux Host Server [LHS]

By DaNnO r0x — version **0.2.0-dev (experimental)**.

[Italian instructions](README.it.md)

Native Linux WinMX chat host with persistent rooms, virtual host, administrator accounts, moderation, an SSH terminal console and experimental WPN publication.

## Download and installation

This package distributes compiled binaries only. Application source code is not included. No Go installation is required.

Supported packages: Linux ARMv7 (32-bit Raspberry Pi OS), ARM64 and x86-64. The ARMv7 build was tested on a Raspberry Pi 3 Model B running Raspbian 13; other targets are cross-compiled and have not been tested on hardware.

Extract the release archive, enter its LxServer directory and run:

```sh
sha256sum -c SHA256SUMS
sudo sh scripts/install.sh
sudo nano /etc/lxserver/config.yaml
sudo systemctl enable --now lxserver
sudo -u lxserver lhsctl status
```

The installer selects the architecture, installs a dedicated service account and preserves existing configuration and service files. It does not start the service automatically. Example room: LxServer Community, TCP port 6699, virtual host LHS_Host. Review the configuration before starting.

## Administration

```sh
sudo -u lxserver lhsctl chat --room main
sudo -u lxserver lhsctl console
sudo -u lxserver lhsctl room rename main "My channel"
sudo -u lxserver lhsctl room topic main "[LHS] My topic"
sudo -u lxserver lhsctl room nick main MyHost
sudo journalctl -u lxserver -n 50 --no-pager
```

Room settings are stored in SQLite after their first initialization; use lhsctl to edit them. The YAML file controls global settings. Global WPN changes require a service restart.

To create an administrator account in Bash without echoing its password:

```bash
sudo -v
read -rsp 'Channel admin password (8–128 characters): ' channel_secret; echo
printf '%s\n' "$channel_secret" | sudo -u lxserver lhsctl account set --room main MyAdmin administrator --password-stdin
unset channel_secret
```

Inside the WinMX channel: `/login MyAdmin YOUR_PASSWORD`. Authenticate again after reconnecting. Do not reuse SSH passwords. WinMX uses historical protocol encryption, not modern transport security.

## Public WPN listing

WPN publication is disabled by default. To enable it, configure the following existing section in `/etc/lxserver/config.yaml`:

```yaml
wpn:
  enabled: true
  caches: ["caches.winmxworld.net:7950"]
  primaries: []
```

Then run `sudo systemctl restart lxserver`. Check `sudo -u lxserver lhsctl status` and independently refresh a WinMX channel list. A connected routing session alone does not prove that the listing is visible.

For Internet joins, forward the configured TCP room port on your router to the server's fixed LAN address. The software does not configure NAT. Allow the port through your firewall. Listing visibility and incoming TCP reachability are separate checks. After renaming, some clients may retain old list entries until refreshed.

## Backup and removal

```sh
sudo -u lxserver lhsctl backup /var/lib/lxserver/manual-backup.db
sudo -u lxserver lxserver -verify-backup /var/lib/lxserver/manual-backup.db
sudo sh scripts/uninstall.sh
```

Uninstallation preserves configuration and data. Update and restore helpers are included; read them before running. The restore helper assumes the default database path.

## Status and limits

Encrypted joins and message exchange with the macOS client's real transport, systemd service operation on the Raspberry Pi, and independent public WPN listing visibility have been verified. Original Windows WinMX acceptance, extended load/soak tests and every Linux target remain unverified. Password-protected legacy WinMX room joins are refused; private messages are not implemented. This is an experimental release.

## Distribution notices

Third-party licenses and attribution are included in `third_party/` and must accompany redistributed binaries. This package does not grant an open-source license to the LxServer application. The author's application distribution license has not yet been specified. Dependency licenses remain applicable independently.

## GitHub publication

Upload the extracted README files and documentation to your public repository. Attach the release archive to a GitHub Release. Do not upload the separate source archive, real configuration, SQLite databases, backups or credentials. This package contains only a generic example configuration.
