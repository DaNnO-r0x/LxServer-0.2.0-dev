# LxServer Linux Host Server [LHS]

By DaNnO r0x — versione **0.2.0-dev (sperimentale)**.

[English instructions](README.md)

Server chat WinMX nativo per Linux, con stanze persistenti, host virtuale, account amministratori, moderazione, console via SSH e pubblicazione WPN sperimentale.

## Download e installazione

Il pacchetto contiene esclusivamente binari compilati, senza il codice sorgente dell’applicazione. Non serve installare Go.

Architetture incluse: Linux ARMv7 (Raspberry Pi OS a 32 bit), ARM64 e x86-64. La versione ARMv7 è stata provata su Raspberry Pi 3 Model B con Raspbian 13; gli altri binari sono stati compilati ma non provati su hardware.

Estrai l’archivio, entra nella cartella LxServer ed esegui:

```sh
sha256sum -c SHA256SUMS
sudo sh scripts/install.sh
sudo nano /etc/lxserver/config.yaml
sudo systemctl enable --now lxserver
sudo -u lxserver lhsctl status
```

L’installer seleziona l’architettura, crea un utente dedicato e conserva eventuali configurazioni e unità di servizio esistenti. Non avvia automaticamente il servizio. Stanza di esempio: LxServer Community, TCP 6699, host virtuale LHS_Host. Controlla la configurazione prima dell’avvio.

## Amministrazione

```sh
sudo -u lxserver lhsctl chat --room main
sudo -u lxserver lhsctl console
sudo -u lxserver lhsctl room rename main "Il mio canale"
sudo -u lxserver lhsctl room topic main "[LHS] Il mio topic"
sudo -u lxserver lhsctl room nick main MioHost
sudo journalctl -u lxserver -n 50 --no-pager
```

Dopo la prima inizializzazione le impostazioni delle stanze vengono salvate in SQLite: modificale tramite lhsctl. Il file YAML controlla le impostazioni globali. Le modifiche globali WPN richiedono il riavvio del servizio.

Per creare un amministratore da Bash senza mostrare la password:

```bash
sudo -v
read -rsp 'Password amministratore (8–128 caratteri): ' channel_secret; echo
printf '%s\n' "$channel_secret" | sudo -u lxserver lhsctl account set --room main MioAdmin administrator --password-stdin
unset channel_secret
```

Dentro il canale WinMX: `/login MioAdmin TUA_PASSWORD`. Ripeti il login dopo ogni riconnessione. Non riutilizzare la password SSH. WinMX impiega la cifratura storica del protocollo, non una protezione di trasporto moderna.

## Pubblicazione WPN

La pubblicazione è disattivata per impostazione predefinita. Per abilitarla modifica la sezione esistente in `/etc/lxserver/config.yaml`:

```yaml
wpn:
  enabled: true
  caches: ["caches.winmxworld.net:7950"]
  primaries: []
```

Esegui `sudo systemctl restart lxserver`. Controlla `sudo -u lxserver lhsctl status` e aggiorna l’elenco canali da un client indipendente. La sola connessione alla rete di instradamento non dimostra che la stanza sia visibile.

Per consentire gli ingressi da Internet, inoltra sul router la porta TCP della stanza verso l’indirizzo LAN fisso del server e autorizzala nel firewall. Il software non configura il NAT. Visibilità nell’elenco e raggiungibilità TCP sono verifiche distinte. Dopo una rinomina alcuni client possono conservare vecchie voci fino all’aggiornamento.

## Backup e disinstallazione

```sh
sudo -u lxserver lhsctl backup /var/lib/lxserver/manual-backup.db
sudo -u lxserver lxserver -verify-backup /var/lib/lxserver/manual-backup.db
sudo sh scripts/uninstall.sh
```

La disinstallazione conserva configurazione e dati. Sono inclusi script di aggiornamento e ripristino: leggili prima di usarli. Il ripristino presume il percorso predefinito del database.

## Stato e limiti

Verificati ingresso cifrato e messaggi con il trasporto reale del client macOS, servizio systemd sul Raspberry Pi e visibilità pubblica WPN da un osservatore indipendente. Restano da verificare il WinMX originale per Windows, carichi prolungati e tutte le architetture Linux. Gli ingressi WinMX legacy con password di stanza sono rifiutati; i messaggi privati non sono implementati. La versione è sperimentale.

## Note sulla distribuzione

Le licenze e attribuzioni delle dipendenze sono incluse in `third_party/` e devono accompagnare i binari ridistribuiti. Questo pacchetto non concede una licenza open source sull’applicazione LxServer. L’autore non ha ancora specificato una licenza di distribuzione dell’applicazione. Restano applicabili separatamente le licenze delle dipendenze.

## Pubblicazione su GitHub

Carica i README estratti e la documentazione nel repository pubblico. Allega l’archivio alla sezione Releases. Non caricare l’archivio separato dei sorgenti, configurazioni reali, database SQLite, backup o credenziali. Il pacchetto contiene soltanto una configurazione generica di esempio.
