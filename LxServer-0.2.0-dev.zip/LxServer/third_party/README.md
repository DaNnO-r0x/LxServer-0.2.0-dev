# Third-party notices

LxServer Linux Host Server [LHS] — By DaNnO r0x

The separately attributed BSD WinMX crypto code is incorporated below;
GPL reference implementations are not incorporated.
Dependencies below are linked by the host build. Original license/notice files
are copied into the corresponding subdirectory. The Go runtime license is in Go/.

| Module | Version | Included notices |
| --- | --- | --- |
| `github.com/dustin/go-humanize` | `v1.0.1` | LICENSE |
| `github.com/google/uuid` | `v1.6.0` | LICENSE |
| `github.com/mattn/go-isatty` | `v0.0.20` | LICENSE |
| `github.com/ncruces/go-strftime` | `v1.0.0` | LICENSE |
| `github.com/remyoudompheng/bigfft` | `v0.0.0-20230129092748-24d4a6f8daec` | LICENSE |
| `go.yaml.in/yaml/v3` | `v3.0.4` | LICENSE, NOTICE |
| `golang.org/x/exp` | `v0.0.0-20251023183803-a4bb9ffd2546` | LICENSE, PATENTS |
| `golang.org/x/sys` | `v0.37.0` | LICENSE, PATENTS |
| `modernc.org/libc` | `v1.67.6` | LICENSE, AUTHORS, LICENSE-3RD-PARTY.md |
| `modernc.org/mathutil` | `v1.7.1` | LICENSE, AUTHORS |
| `modernc.org/memory` | `v1.11.0` | LICENSE, AUTHORS, LICENSE-MMAP-GO, LICENSE-LOGO, LICENSE-GO |
| `modernc.org/sqlite` | `v1.46.1` | LICENSE, AUTHORS |

Project distribution license has not been selected by the author.

## Incorporated protocol crypto

`internal/protocol/winmx/legacycrypto` incorporates required parts of
[WinMX/wpnp-crypto-go](https://github.com/WinMX/wpnp-crypto-go), commit
0017455dcaf05756059a846f2baecbdd5d1267ac, Copyright (c) 2021 Josh Glazebrook,
BSD-3-Clause. Full license is in WinMX_wpnp-crypto-go/LICENSE and beside the code.
Changes: chat/discovery operations selected, crypto/rand with error returns,
and grouped Go switch cases for paired client/server key IDs.
No GPL reference implementation is linked or incorporated; numerical vectors
from a separate C test tool retain their source/digest provenance in testdata.
